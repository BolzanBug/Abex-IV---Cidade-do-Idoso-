// Global variables
let currentSlide = 0;
let totalSlides = 3;
let autoSlideInterval;

// Initialize page
document.addEventListener('DOMContentLoaded', async function() {
    // Carrega avatar salvo
    loadSavedAvatar();

    // 1. Verifica autenticação antes de renderizar
    const isAuthenticated = await checkAuthentication();

    if (isAuthenticated) {
        initializeCarousel();
        setupEventListeners();
        initializeAccessibility();
    }
});

// --- AVATAR / FOTO DE PERFIL ---

function loadSavedAvatar() {
    const saved = localStorage.getItem('userAvatar');
    if (saved) {
        const img = document.getElementById('user-avatar');
        if (img) img.src = saved;
    }
}

function changeAvatar(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        const src = e.target.result;
        const img = document.getElementById('user-avatar');
        if (img) img.src = src;
        localStorage.setItem('userAvatar', src);
    };
    reader.readAsDataURL(file);
}
window.changeAvatar = changeAvatar;

// --- LÓGICA DE AUTENTICAÇÃO ---

async function checkAuthentication() {
    const token = localStorage.getItem("token");

    if (!token) {
        console.warn("Nenhum token encontrado. Redirecionando para login.");
        window.location.href = "login.html";
        return false;
    }

    try {
        const base =
            typeof window.API_BASE_URL === 'string' && window.API_BASE_URL
                ? window.API_BASE_URL
                : 'http://localhost:8000';
        const response = await fetch(`${base}/users/me`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        if (response.ok) {
            const userData = await response.json();

            if (userData.is_staff) {
                window.location.href = "funcionario-home.html";
                return false;
            }

            // Atualiza a interface com os dados do usuário
            const greetingElement = document.getElementById("user-greeting");
            const welcomeTitle = document.getElementById("welcome-title");

            // Prioriza o primeiro nome, se não tiver, usa o username
            const nomeExibicao = [userData.first_name, userData.last_name].filter(Boolean).join(" ") || userData.username;

            if (greetingElement) {
                greetingElement.textContent = `Olá, ${nomeExibicao}`;
                greetingElement.style.display = 'block';
            }
            if (welcomeTitle) {
                welcomeTitle.textContent = `Bem-vindo(a), ${nomeExibicao}!`;
            }

            return true;
        } else {
            console.warn("Sessão inválida. Redirecionando para login.");
            localStorage.removeItem("token");
            window.location.href = "login.html";
            return false;
        }
    } catch (error) {
        console.error("Erro ao validar token com o servidor:", error);
        return true;
    }
}

function logout() {
    localStorage.removeItem("token");
    window.location.href = "login.html";
}
window.logout = logout;


// --- CARROSSEL DINÂMICO COM NOTÍCIAS DO CLICRDC ---

async function loadCarouselNews() {
    const carousel = document.getElementById('newsCarousel');
    const dotsContainer = document.getElementById('carouselDots');

    // Usa proxy público de RSS para contornar CORS
    const rssUrl = 'https://clicrdc.com.br/feed/';
    const proxyUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}&count=5`;

    try {
        const resp = await fetch(proxyUrl);
        if (!resp.ok) throw new Error('Falha ao buscar RSS');
        const data = await resp.json();

        if (!data.items || data.items.length === 0) throw new Error('Sem itens');

        const items = data.items.slice(0, 5);
        totalSlides = items.length;

        // Limpa carousel e dots
        carousel.innerHTML = '';
        dotsContainer.innerHTML = '';

        items.forEach((item, index) => {
            // Remove HTML das tags da descrição
            const div = document.createElement('div');
            div.innerHTML = item.description || '';
            const descText = div.textContent.trim().slice(0, 120) + '...';

            const slide = document.createElement('div');
            slide.className = 'news-item' + (index === 0 ? ' active' : '');
            slide.setAttribute('data-index', index);
            slide.setAttribute('tabindex', '0');
            slide.setAttribute('role', 'button');
            slide.setAttribute('aria-label', `Notícia ${index + 1}: ${item.title}`);

            const imgSrc = item.enclosure?.link || item.thumbnail || 'IMAGENS/avatar-generico.svg';

            slide.innerHTML = `
                <div class="news-image">
                    <img src="${imgSrc}" alt="" onerror="this.style.display='none'">
                </div>
                <div class="news-content">
                    <h3>${item.title}</h3>
                    <p>${descText}</p>
                    <div class="news-meta">
                        <span class="news-category">ClicRDC</span>
                        <span class="news-date">${new Date(item.pubDate).toLocaleDateString('pt-BR')}</span>
                    </div>
                </div>
            `;

            slide.addEventListener('click', () => {
                window.open('noticias.html', '_self');
            });
            slide.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    window.location.assign('noticias.html');
                }
            });

            carousel.appendChild(slide);

            // Dot
            const dot = document.createElement('span');
            dot.className = 'dot' + (index === 0 ? ' active' : '');
            dot.onclick = () => { currentSlideFunc(index + 1); };
            dotsContainer.appendChild(dot);
        });

    } catch (err) {
        console.warn('Não foi possível carregar notícias do ClicRDC:', err);
        // Mantém slide padrão de fallback
        carousel.innerHTML = `
            <div class="news-item active" data-index="0">
                <div class="news-content" style="padding: 40px; text-align: center;">
                    <h3>Fique por dentro das notícias</h3>
                    <p>Acesse a aba de Notícias para ver os comunicados e novidades mais recentes do Portal.</p>
                    <div class="news-meta" style="margin-top:10px;">
                        <span class="news-category">Portal</span>
                    </div>
                </div>
            </div>
        `;
        totalSlides = 1;
        dotsContainer.innerHTML = '<span class="dot active"></span>';
    }

    currentSlide = 0;
}


// --- LÓGICA DO CARROSSEL E NAVEGAÇÃO ---

function initializeCarousel() {
    startAutoSlide();
    const newsItems = document.querySelectorAll('.news-item');
    newsItems.forEach((item) => {
        item.addEventListener('click', function () {
            window.location.assign('noticias.html');
        });
    });
}

function startAutoSlide() {
    autoSlideInterval = setInterval(() => { nextSlide(); }, 4000);
}

function stopAutoSlide() { clearInterval(autoSlideInterval); }

function restartAutoSlide() {
    stopAutoSlide();
    startAutoSlide();
}

function showSlide(n) {
    const slides = document.querySelectorAll('.news-item');
    const dots = document.querySelectorAll('.dot');

    if (n >= totalSlides) currentSlide = 0;
    if (n < 0) currentSlide = totalSlides - 1;

    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    if (slides[currentSlide]) slides[currentSlide].classList.add('active');
    if (dots[currentSlide]) dots[currentSlide].classList.add('active');
}

function nextSlide() { currentSlide++; showSlide(currentSlide); }
function prevSlide() { currentSlide--; showSlide(currentSlide); restartAutoSlide(); }
function currentSlideFunc(n) { currentSlide = n - 1; showSlide(currentSlide); restartAutoSlide(); }

window.nextSlide = nextSlide;
window.prevSlide = prevSlide;
window.currentSlide = currentSlideFunc;

// --- FUNÇÕES DE ACESSIBILIDADE E UTILITÁRIOS ---
// Gerenciado por voice-accessibility.js

function setupEventListeners() {
    const carousel = document.getElementById('newsCarousel');
    if (carousel) {
        carousel.addEventListener('mouseenter', stopAutoSlide);
        carousel.addEventListener('mouseleave', startAutoSlide);
    }

    const infoCards = document.querySelectorAll('.info-card');
    infoCards.forEach((card, index) => {
        card.addEventListener('click', function () {
            switch (index) {
                case 0: window.location.assign('atividades.html'); break;
                case 1: window.location.assign('cardapio.html'); break;
                case 2: window.location.assign('noticias.html'); break;
                default: break;
            }
        });
        card.style.cursor = 'pointer';
    });
}

function initializeAccessibility() {
    document.addEventListener('keydown', function(event) {
        if (event.key === 'ArrowLeft') prevSlide();
        else if (event.key === 'ArrowRight') nextSlide();
    });
}

document.addEventListener('visibilitychange', function() {
    if (document.hidden) stopAutoSlide();
    else startAutoSlide();
});
