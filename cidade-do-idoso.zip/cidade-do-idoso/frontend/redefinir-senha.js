(function () {
    const API = () =>
        (typeof window.API_BASE_URL === 'string' && window.API_BASE_URL)
            ? window.API_BASE_URL
            : 'http://localhost:8000';

    // Lê token da query string
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token') || '';

    function show(id) {
        ['stateLoading', 'stateInvalid', 'formSection', 'stateSuccess'].forEach(s => {
            const el = document.getElementById(s);
            if (!el) return;
            el.classList.remove('show');
            el.style.display = 'none';
        });
        const target = document.getElementById(id);
        if (target) {
            target.style.display = 'block';
            target.classList.add('show');
        }
    }

    // ── Validação do token ao carregar ─────────────────────────────────────
    async function validarToken() {
        if (!token) {
            document.getElementById('invalidReason').textContent =
                'Nenhum token encontrado neste link. Solicite um novo link de recuperação.';
            show('stateInvalid');
            return;
        }

        try {
            const resp = await fetch(`${API()}/password/reset-validate?token=${encodeURIComponent(token)}`);
            const data = await resp.json().catch(() => ({}));

            if (data.valid) {
                show('formSection');
            } else {
                document.getElementById('invalidReason').textContent =
                    data.reason || 'Este link de recuperação não é mais válido.';
                show('stateInvalid');
            }
        } catch (err) {
            document.getElementById('invalidReason').textContent =
                'Não foi possível verificar o link. Verifique sua conexão.';
            show('stateInvalid');
        }
    }

    // ── Força da senha ─────────────────────────────────────────────────────
    window.togglePw = function (inputId, btn) {
        const input = document.getElementById(inputId);
        const icon = btn.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            input.type = 'password';
            icon.className = 'fas fa-eye';
        }
    };

    document.getElementById('newPassword').addEventListener('input', function () {
        const val = this.value;
        const bar = document.getElementById('strengthBar');
        const label = document.getElementById('strengthLabel');
        bar.className = 'strength-bar';
        if (!val) { label.textContent = ''; return; }
        const hasUpper = /[A-Z]/.test(val);
        const hasNum   = /[0-9]/.test(val);
        const hasSpec  = /[^A-Za-z0-9]/.test(val);
        const score = (val.length >= 8 ? 1 : 0) + (hasUpper ? 1 : 0) + (hasNum ? 1 : 0) + (hasSpec ? 1 : 0);
        if (score <= 1) { bar.classList.add('weak');   label.textContent = 'Senha fraca'; }
        else if (score === 2 || score === 3) { bar.classList.add('medium'); label.textContent = 'Senha média'; }
        else { bar.classList.add('strong'); label.textContent = 'Senha forte'; }
    });

    // ── Redefinição ────────────────────────────────────────────────────────
    window.redefinirSenha = async function () {
        // Limpa erros
        ['pwError', 'confirmError'].forEach(id => {
            const el = document.getElementById(id);
            el.textContent = '';
            el.classList.remove('show');
        });
        document.getElementById('newPassword').classList.remove('error');
        document.getElementById('confirmPassword').classList.remove('error');

        const newPw  = document.getElementById('newPassword').value;
        const confPw = document.getElementById('confirmPassword').value;

        let valid = true;

        if (!newPw || newPw.length < 6) {
            document.getElementById('pwError').textContent = 'A senha deve ter ao menos 6 caracteres.';
            document.getElementById('pwError').classList.add('show');
            document.getElementById('newPassword').classList.add('error');
            valid = false;
        }
        if (newPw !== confPw) {
            document.getElementById('confirmError').textContent = 'As senhas não coincidem.';
            document.getElementById('confirmError').classList.add('show');
            document.getElementById('confirmPassword').classList.add('error');
            valid = false;
        }
        if (!valid) return;

        const btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.classList.add('loading');

        try {
            const resp = await fetch(`${API()}/password/reset-confirm`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token, new_password: newPw }),
            });
            const data = await resp.json().catch(() => ({}));

            if (resp.ok && data.ok) {
                document.getElementById('backLink').style.display = 'none';
                show('stateSuccess');
                return;
            }

            // Erro do backend
            const msg = data.message || 'Erro ao redefinir senha. Tente novamente.';
            if (msg.toLowerCase().includes('expirado') || msg.toLowerCase().includes('inválido')) {
                document.getElementById('invalidReason').textContent = msg;
                show('stateInvalid');
            } else {
                document.getElementById('pwError').textContent = msg;
                document.getElementById('pwError').classList.add('show');
                btn.disabled = false;
                btn.classList.remove('loading');
            }

        } catch (err) {
            document.getElementById('pwError').textContent = 'Erro de conexão. Tente novamente.';
            document.getElementById('pwError').classList.add('show');
            btn.disabled = false;
            btn.classList.remove('loading');
        }
    };

    // Enter nas inputs dispara submit
    ['newPassword', 'confirmPassword'].forEach(id => {
        document.getElementById(id).addEventListener('keydown', function (e) {
            if (e.key === 'Enter') window.redefinirSenha();
        });
    });

    // Inicia
    validarToken();
})();
