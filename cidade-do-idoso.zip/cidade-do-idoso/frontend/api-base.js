/**
 * Base URL da API + lógica de refresh token automático — Sprint 5.
 * Elimina a necessidade de relogin após expiração da sessão JWT.
 */
(function () {
    function resolveApiBase() {
        const meta = document.querySelector('meta[name="api-base"]');
        if (meta && meta.content.trim()) {
            return meta.content.trim().replace(/\/$/, '');
        }
        const { hostname, port, protocol } = window.location;
        if (protocol === 'file:') {
            return 'http://localhost:8000';
        }
        const local = ['localhost', '127.0.0.1', '[::1]'].includes(hostname);
        if (local && (port === '8080' || port === '80' || port === '')) {
            return '/api';
        }
        if (local) {
            return `http://${hostname}:8000`;
        }
        return '/api';
    }

    window.API_BASE_URL = resolveApiBase();

    /**
     * Tenta renovar o token JWT chamando /auth/refresh_token.
     * Retorna true se renovado com sucesso, false caso contrário.
     */
    async function tryRefreshToken() {
        const token = localStorage.getItem('token');
        if (!token) return false;
        try {
            const res = await fetch(`${window.API_BASE_URL}/auth/refresh_token`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}` },
            });
            if (res.ok) {
                const data = await res.json();
                localStorage.setItem('token', data.access_token);
                return true;
            }
        } catch (_) { /* rede indisponível */ }
        return false;
    }

    /**
     * apiFetch — wrapper sobre fetch com refresh token automático.
     * Uso: const res = await apiFetch('/atividades/catalogo');
     * - Injeta Authorization automaticamente.
     * - Se receber 401, tenta refresh e repete a requisição uma vez.
     * - Se refresh falhar, redireciona para login.
     */
    async function apiFetch(path, options = {}) {
        const base = window.API_BASE_URL;
        const url = path.startsWith('http') ? path : `${base}${path}`;

        function buildHeaders(extra = {}) {
            const token = localStorage.getItem('token');
            const h = { ...extra };
            if (token) h['Authorization'] = `Bearer ${token}`;
            return h;
        }

        let res = await fetch(url, {
            ...options,
            headers: { ...buildHeaders(), ...(options.headers || {}) },
        });

        // Se 401 tenta renovar token e repetir
        if (res.status === 401) {
            const renewed = await tryRefreshToken();
            if (renewed) {
                res = await fetch(url, {
                    ...options,
                    headers: { ...buildHeaders(), ...(options.headers || {}) },
                });
            } else {
                localStorage.removeItem('token');
                // Redireciona para login apenas se não estivermos já na página de login
                if (!window.location.pathname.includes('login')) {
                    window.location.href = 'login.html';
                }
                return res;
            }
        }

        return res;
    }

    window.apiFetch = apiFetch;
    window.tryRefreshToken = tryRefreshToken;
})();
