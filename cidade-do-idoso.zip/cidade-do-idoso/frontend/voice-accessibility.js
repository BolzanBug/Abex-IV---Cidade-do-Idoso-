/**
 * voice-accessibility.js — Acessibilidade por Voz
 * Portal Cidade do Idoso — Chapecó
 *
 * Expõe toggleVoiceAccessibility() globalmente logo no início
 * para garantir compatibilidade com onclick="..." nos botões do HTML.
 */

// ── Estado global (acessível antes do DOMContentLoaded) ─────────────────────
window._voiceA11y = {
    enabled: localStorage.getItem('voiceA11yEnabled') === 'true',
    synth:   window.speechSynthesis || null,
    recog:   null,
    ptVoice: null,
    hoverTimer: null,
};

// ── Expõe a função globalmente IMEDIATAMENTE (resolvendo o onclick="...") ────
window.toggleVoiceAccessibility = function () {
    if (window._voiceA11y.enabled) {
        _va_disable();
    } else {
        _va_enable();
    }
};

// ────────────────────────────────────────────────────────────────────────────
// FUNÇÕES INTERNAS
// ────────────────────────────────────────────────────────────────────────────

function _va_speak(text, interrupt) {
    const va = window._voiceA11y;
    if (!va.synth || !va.enabled) return;
    if (interrupt !== false) va.synth.cancel();

    const u = new SpeechSynthesisUtterance(text);
    u.lang   = 'pt-BR';
    u.rate   = 0.92;
    u.pitch  = 1;
    u.volume = 1;
    if (va.ptVoice) u.voice = va.ptVoice;
    va.synth.speak(u);
}

function _va_loadVoice() {
    if (!window._voiceA11y.synth) return;
    const voices = window._voiceA11y.synth.getVoices();
    window._voiceA11y.ptVoice =
        voices.find(v => v.lang === 'pt-BR') ||
        voices.find(v => v.lang.startsWith('pt')) ||
        null;
}

function _va_updateButtons() {
    const enabled = window._voiceA11y.enabled;
    document.querySelectorAll('.accessibility-btn').forEach(btn => {
        if (enabled) {
            btn.classList.add('active');
            btn.setAttribute('aria-pressed', 'true');
            btn.innerHTML = '<i class="fas fa-volume-off"></i><span>Desativar acessibilidade por voz</span>';
        } else {
            btn.classList.remove('active');
            btn.setAttribute('aria-pressed', 'false');
            btn.innerHTML = '<i class="fas fa-volume-up"></i><span>Ativar acessibilidade por voz</span>';
        }
    });
}

function _va_readPage() {
    const blocks = [];

    // Título e saudação
    const h1 = document.querySelector('h1.main-title, h1');
    if (h1) blocks.push(h1.textContent.trim());

    const greeting = document.getElementById('user-greeting');
    if (greeting && greeting.offsetParent !== null) blocks.push(greeting.textContent.trim());

    // Conteúdo da main
    const main = document.querySelector('main, .main-content');
    if (main) {
        main.querySelectorAll('h2, h3, p, .news-content p, .noticia-card-titulo, .noticia-card-desc').forEach(el => {
            const t = el.textContent.trim();
            if (t.length > 4 && t.length < 400 && !blocks.includes(t)) blocks.push(t);
        });
    }

    const text = blocks.join('. ').replace(/\s+/g, ' ').trim();
    _va_speak(text || 'Não há conteúdo para ler nesta página.');
}

function _va_showPanel() {
    if (document.getElementById('va-panel')) return;
    const panel = document.createElement('div');
    panel.id = 'va-panel';
    panel.setAttribute('role', 'status');
    panel.setAttribute('aria-live', 'polite');
    panel.style.cssText = `
        position:fixed; bottom:76px; right:14px;
        background:#01200F; color:#fff;
        border:1px solid rgba(0,185,49,0.5);
        border-radius:12px; padding:10px 14px;
        font-size:12px; font-family:Inter,sans-serif;
        z-index:9999; box-shadow:0 4px 20px rgba(0,0,0,0.4);
        display:flex; align-items:center; gap:8px;
        cursor:pointer; max-width:210px;
    `;
    panel.title = 'Clique para ouvir os comandos disponíveis';
    panel.onclick = () => _va_speak(
        'Comandos de voz disponíveis: início, atividades, cardápio, notícias, sair, parar, ler página, ajuda, desativar voz.'
    );

    const hasMic = !!(window.SpeechRecognition || window.webkitSpeechRecognition);
    panel.innerHTML = `
        <span style="font-size:18px;line-height:1;">🎤</span>
        <div>
            <div style="font-weight:700;color:#00B931;">Voz ativa</div>
            <div style="opacity:.8;margin-top:2px;">${hasMic ? 'Leitura + comandos' : 'Somente leitura'}</div>
        </div>
    `;
    document.body.appendChild(panel);
}

function _va_removePanel() {
    const p = document.getElementById('va-panel');
    if (p) p.remove();
}

// ── Hover: narrar elemento ao passar o mouse ─────────────────────────────────
const VA_HOVER_SELECTOR = 'button, a[href], .nav-item, .info-card, .news-item, .noticia-card, [role="button"], input, select, label';

function _va_onEnter(e) {
    if (!window._voiceA11y.enabled) return;
    clearTimeout(window._voiceA11y.hoverTimer);
    const el  = e.currentTarget;
    const txt = (el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent || '')
        .trim().replace(/\s+/g, ' ').slice(0, 150);
    if (txt) {
        window._voiceA11y.hoverTimer = setTimeout(() => _va_speak(txt, false), 700);
    }
}
function _va_onLeave() { clearTimeout(window._voiceA11y.hoverTimer); }

function _va_addHover() {
    document.querySelectorAll(VA_HOVER_SELECTOR).forEach(el => {
        el.addEventListener('mouseenter', _va_onEnter);
        el.addEventListener('mouseleave', _va_onLeave);
    });
}
function _va_removeHover() {
    document.querySelectorAll(VA_HOVER_SELECTOR).forEach(el => {
        el.removeEventListener('mouseenter', _va_onEnter);
        el.removeEventListener('mouseleave', _va_onLeave);
    });
}

// ── Foco por teclado ─────────────────────────────────────────────────────────
function _va_onFocus(e) {
    if (!window._voiceA11y.enabled) return;
    const el  = e.target;
    const txt = (el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent || el.getAttribute('placeholder') || '')
        .trim().replace(/\s+/g, ' ').slice(0, 150);
    if (txt) _va_speak(txt, false);
}

// ── Reconhecimento de voz ────────────────────────────────────────────────────
const VA_COMMANDS = [
    { words: ['início','home','página inicial'],     fn: () => _va_nav('home.html', 'página inicial') },
    { words: ['atividades','atividade'],             fn: () => _va_nav('atividades.html', 'atividades') },
    { words: ['cardápio','cardapio','comida'],        fn: () => _va_nav('cardapio.html', 'cardápio') },
    { words: ['notícias','noticias','novidades'],     fn: () => _va_nav('noticias.html', 'notícias') },
    { words: ['sair','logout','deslogar'],            fn: () => { _va_speak('Saindo.'); setTimeout(() => { localStorage.removeItem('token'); location.href='login.html'; }, 1400); } },
    { words: ['parar','silêncio','calar'],            fn: () => window._voiceA11y.synth?.cancel() },
    { words: ['ler página','ler tudo','leia'],        fn: () => _va_readPage() },
    { words: ['ajuda','comandos'],                   fn: () => _va_speak('Comandos: início, atividades, cardápio, notícias, sair, parar, ler página, desativar voz.') },
    { words: ['desativar voz','desligar voz'],        fn: () => _va_disable() },
];

function _va_nav(page, label) {
    _va_speak('Navegando para ' + label);
    setTimeout(() => { location.href = page; }, 1300);
}

function _va_startRecog() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;

    const va = window._voiceA11y;
    if (va.recog) { try { va.recog.abort(); } catch(_){} }

    const r = new SR();
    r.lang = 'pt-BR';
    r.continuous = true;
    r.interimResults = false;

    r.onresult = e => {
        const transcript = Array.from(e.results)
            .slice(e.resultIndex)
            .map(res => res[0].transcript.toLowerCase().trim())
            .join(' ');

        for (const cmd of VA_COMMANDS) {
            if (cmd.words.some(w => transcript.includes(w))) {
                cmd.fn();
                return;
            }
        }
    };

    r.onerror = e => {
        if (e.error === 'not-allowed') {
            _va_speak('Microfone não autorizado. Somente leitura ativa.');
        }
        if (['network','no-speech','aborted'].includes(e.error) && va.enabled) {
            setTimeout(() => { try { va.recog?.start(); } catch(_){} }, 1000);
        }
    };

    r.onend = () => {
        if (va.enabled) setTimeout(() => { try { r.start(); } catch(_){} }, 600);
    };

    va.recog = r;
    try { r.start(); } catch(_) {}
}

function _va_stopRecog() {
    const va = window._voiceA11y;
    if (va.recog) { try { va.recog.abort(); } catch(_){} va.recog = null; }
}

// ── Ativar / Desativar ───────────────────────────────────────────────────────
function _va_enable() {
    const va = window._voiceA11y;
    if (!va.synth) {
        alert('Seu navegador não suporta leitura de voz. Use Chrome ou Edge.');
        return;
    }
    va.enabled = true;
    localStorage.setItem('voiceA11yEnabled', 'true');
    _va_updateButtons();
    _va_showPanel();
    _va_addHover();
    document.addEventListener('focusin', _va_onFocus);
    _va_startRecog();
    _va_speak('Acessibilidade por voz ativada.');
    setTimeout(_va_readPage, 2000);
}

function _va_disable() {
    const va = window._voiceA11y;
    va.enabled = false;
    localStorage.setItem('voiceA11yEnabled', 'false');
    va.synth?.cancel();
    _va_stopRecog();
    _va_removeHover();
    document.removeEventListener('focusin', _va_onFocus);
    _va_removePanel();
    _va_updateButtons();
}

// ── API pública ──────────────────────────────────────────────────────────────
window.voiceA11y = {
    speak:    _va_speak,
    announce: msg => { if (window._voiceA11y.enabled) _va_speak(msg); },
    isEnabled: () => window._voiceA11y.enabled,
    readPage: _va_readPage,
};

// ── Inicialização após DOM pronto ────────────────────────────────────────────
function _va_init() {
    _va_loadVoice();
    if (window._voiceA11y.synth) {
        window._voiceA11y.synth.onvoiceschanged = _va_loadVoice;
    }

    // Sincroniza botões com o estado salvo
    _va_updateButtons();

    // Se estava ativo antes (localStorage), reativa silenciosamente
    if (window._voiceA11y.enabled) {
        _va_showPanel();
        _va_addHover();
        document.addEventListener('focusin', _va_onFocus);
        _va_startRecog();
        // Não lê a página automaticamente no recarregamento, só anuncia
        _va_speak('Acessibilidade por voz ativa.');
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _va_init);
} else {
    _va_init();
}
