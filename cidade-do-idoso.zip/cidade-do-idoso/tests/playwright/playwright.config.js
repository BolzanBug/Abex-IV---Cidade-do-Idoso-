// playwright.config.js — Sprint 5: Testes end-to-end com suporte a zoom e acessibilidade
const { defineConfig, devices } = require('@playwright/test');

module.exports = defineConfig({
    testDir: './tests',
    timeout: 30_000,
    retries: 1,
    reporter: [['html', { open: 'never' }], ['list']],
    use: {
        baseURL: process.env.BASE_URL || 'http://localhost:8080',
        trace: 'on-first-retry',
        screenshot: 'only-on-failure',
    },
    projects: [
        {
            name: 'Desktop — zoom normal',
            use: {
                ...devices['Desktop Chrome'],
                viewport: { width: 1280, height: 720 },
                deviceScaleFactor: 1,
            },
        },
        {
            name: 'Desktop — zoom 150%',
            use: {
                ...devices['Desktop Chrome'],
                // Simula zoom de 150% com deviceScaleFactor
                viewport: { width: 854, height: 480 },
                deviceScaleFactor: 1.5,
            },
        },
        {
            name: 'Desktop — zoom 200%',
            use: {
                ...devices['Desktop Chrome'],
                // Simula zoom de 200% — detecta quebras de layout
                viewport: { width: 640, height: 360 },
                deviceScaleFactor: 2,
            },
        },
        {
            name: 'Mobile',
            use: { ...devices['Pixel 5'] },
        },
    ],
});
