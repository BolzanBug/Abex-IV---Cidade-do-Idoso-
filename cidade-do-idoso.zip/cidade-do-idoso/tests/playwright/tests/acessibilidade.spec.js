// tests/acessibilidade.spec.js — Sprint 5
// 8 testes automatizados de acessibilidade: zoom, teclado, ARIA.

const { test, expect } = require('@playwright/test');

// Páginas secundárias a testar
const PAGINAS = [
    { nome: 'cardápio', path: '/cardapio.html' },
    { nome: 'notícias', path: '/noticias.html' },
    { nome: 'atividades', path: '/atividades.html' },
];

// =====================================================================
// TESTE 1 — Skip link presente e funcional em todas as telas
// =====================================================================
for (const pagina of PAGINAS) {
    test(`[ACCESS-01] Skip link presente — ${pagina.nome}`, async ({ page }) => {
        await page.goto(pagina.path);
        const skipLink = page.locator('.skip-link');
        await expect(skipLink).toBeAttached();

        // O skip link deve ficar visível ao receber foco via teclado
        await skipLink.focus();
        await expect(skipLink).toBeVisible();
    });
}

// =====================================================================
// TESTE 2 — Navegação por teclado na nav inferior
// =====================================================================
test('[ACCESS-02] Navegação inferior acessível por teclado', async ({ page }) => {
    await page.goto('/atividades.html');

    // Tab pela navegação inferior
    const navItems = page.locator('.bottom-nav .nav-item');
    const count = await navItems.count();
    expect(count).toBeGreaterThan(0);

    // Cada item deve ter aria-label
    for (let i = 0; i < count; i++) {
        const item = navItems.nth(i);
        const ariaLabel = await item.getAttribute('aria-label');
        expect(ariaLabel, `nav-item[${i}] deve ter aria-label`).toBeTruthy();
    }
});

// =====================================================================
// TESTE 3 — Atributos ARIA obrigatórios nos componentes
// =====================================================================
test('[ACCESS-03] Atributos ARIA nos componentes principais — atividades', async ({ page }) => {
    await page.goto('/atividades.html');

    // grid de atividades deve ter aria-live
    const grid = page.locator('#activitiesGrid');
    await expect(grid).toHaveAttribute('aria-live', 'polite');

    // nav inferior deve ter aria-label
    const nav = page.locator('.bottom-nav');
    await expect(nav).toHaveAttribute('aria-label');

    // Página atual marcada com aria-current
    const activeNav = page.locator('.bottom-nav .nav-item.active');
    await expect(activeNav).toHaveAttribute('aria-current', 'page');
});

// =====================================================================
// TESTE 4 — ARIA obrigatórios no cardápio
// =====================================================================
test('[ACCESS-04] Atributos ARIA — cardápio', async ({ page }) => {
    await page.goto('/cardapio.html');

    const container = page.locator('#cardapioContainer');
    await expect(container).toHaveAttribute('aria-live', 'polite');

    const loading = page.locator('#loadingSpinner');
    await expect(loading).toHaveAttribute('aria-label');

    // Cabeçalho de seção referenciado via aria-labelledby
    const section = page.locator('section.cardapio-section');
    const labelledBy = await section.getAttribute('aria-labelledby');
    expect(labelledBy).toBeTruthy();
    const heading = page.locator(`#${labelledBy}`);
    await expect(heading).toBeAttached();
});

// =====================================================================
// TESTE 5 — ARIA obrigatórios nas notícias
// =====================================================================
test('[ACCESS-05] Atributos ARIA — notícias', async ({ page }) => {
    await page.goto('/noticias.html');

    const container = page.locator('#newsContainer');
    await expect(container).toHaveAttribute('aria-live', 'polite');

    const error = page.locator('#errorMessage');
    await expect(error).toHaveAttribute('aria-live', 'assertive');
});

// =====================================================================
// TESTE 6 — Layout sem quebra a zoom 150% (viewport simulado)
// =====================================================================
test('[ACCESS-06] Layout íntegro com zoom 150%', async ({ page }) => {
    // viewport smaller + deviceScaleFactor já configurado no playwright.config
    await page.goto('/atividades.html');

    // Navegação inferior não deve transbordar horizontalmente
    const nav = page.locator('.bottom-nav');
    const navBox = await nav.boundingBox();
    const viewportWidth = page.viewportSize().width;

    if (navBox) {
        expect(navBox.width).toBeLessThanOrEqual(viewportWidth + 2); // 2px tolerância
    }

    // O container principal não deve causar scroll horizontal
    const body = page.locator('body');
    const bodyOverflow = await body.evaluate(el => getComputedStyle(el).overflowX);
    // overflow 'hidden' ou ausência de scrollbar lateral é aceitável
    // checamos que a largura do scroll não excede o viewport
    const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    expect(scrollWidth).toBeLessThanOrEqual(viewportWidth + 16);
});

// =====================================================================
// TESTE 7 — Imagens com atributo alt
// =====================================================================
test('[ACCESS-07] Todas as imagens têm atributo alt', async ({ page }) => {
    for (const pagina of PAGINAS) {
        await page.goto(pagina.path);
        const imagens = page.locator('img');
        const count = await imagens.count();

        for (let i = 0; i < count; i++) {
            const img = imagens.nth(i);
            const alt = await img.getAttribute('alt');
            // alt pode ser vazio string ('') para imagens decorativas, mas não null/undefined
            expect(alt, `Imagem ${i} em ${pagina.nome} deve ter atributo alt`).not.toBeNull();
        }
    }
});

// =====================================================================
// TESTE 8 — Botões e links com texto acessível
// =====================================================================
test('[ACCESS-08] Botões e links com texto acessível — atividades', async ({ page }) => {
    await page.goto('/atividades.html');

    const buttons = page.locator('button');
    const count = await buttons.count();

    for (let i = 0; i < count; i++) {
        const btn = buttons.nth(i);
        const text = (await btn.innerText()).trim();
        const ariaLabel = await btn.getAttribute('aria-label');
        const ariaLabelledBy = await btn.getAttribute('aria-labelledby');

        const hasAccessibleName = text.length > 0 || ariaLabel || ariaLabelledBy;
        expect(
            hasAccessibleName,
            `Botão ${i} deve ter nome acessível (texto, aria-label ou aria-labelledby)`
        ).toBeTruthy();
    }
});
