// tests/fluxos-usuario.spec.js — Sprint 5
// Testes end-to-end dos fluxos principais do portal (idoso).

const { test, expect } = require('@playwright/test');

const BASE = process.env.BASE_URL || 'http://localhost:8080';
const API  = process.env.API_URL  || 'http://localhost:8000';

// Helper: login via API e retorna token
async function obterToken(request, email = 'teste@idoso.com', senha = 'senha123') {
    const res = await request.post(`${API}/auth/token`, {
        form: { username: email, password: senha },
    });
    if (!res.ok()) return null;
    const data = await res.json();
    return data.access_token;
}

// Helper: injeta token no localStorage via page.addInitScript
async function loginPage(page, token) {
    await page.addInitScript((t) => {
        localStorage.setItem('token', t);
    }, token);
}

// =====================================================================
// FLUXO 1 — Página de login renderiza corretamente
// =====================================================================
test('[FLOW-01] Página de login renderiza formulário', async ({ page }) => {
    await page.goto('/login.html');
    await expect(page.locator('input[type="email"], input[name="email"], #email, [placeholder*="email" i]').first()).toBeVisible();
    await expect(page.locator('input[type="password"]').first()).toBeVisible();
    await expect(page.locator('button[type="submit"], button:has-text("Entrar"), button:has-text("Login")').first()).toBeVisible();
});

// =====================================================================
// FLUXO 2 — Cardápio carrega sem login
// =====================================================================
test('[FLOW-02] Cardápio carrega (acesso público)', async ({ page }) => {
    await page.goto('/cardapio.html');
    // Aguarda o container ser preenchido ou exibir algum conteúdo
    const container = page.locator('#cardapioContainer');
    await expect(container).toBeVisible({ timeout: 8000 });
});

// =====================================================================
// FLUXO 3 — Notícias carregam sem login
// =====================================================================
test('[FLOW-03] Notícias carregam (acesso público)', async ({ page }) => {
    await page.goto('/noticias.html');
    const container = page.locator('#newsContainer');
    await expect(container).toBeVisible({ timeout: 8000 });
});

// =====================================================================
// FLUXO 4 — Navegação entre telas via nav inferior funciona
// =====================================================================
test('[FLOW-04] Navegação entre telas via bottom nav', async ({ page }) => {
    await page.goto('/cardapio.html');

    // Clica em Notícias
    const navNoticias = page.locator('.bottom-nav a[href="noticias.html"]');
    await expect(navNoticias).toBeVisible();
    await navNoticias.click();
    await expect(page).toHaveURL(/noticias\.html/);

    // Clica em Atividades
    const navAtividades = page.locator('.bottom-nav a[href="atividades.html"]');
    await navAtividades.click();
    await expect(page).toHaveURL(/atividades\.html/);

    // Volta para Home
    const navHome = page.locator('.bottom-nav a[href="home.html"]');
    await navHome.click();
    await expect(page).toHaveURL(/home\.html/);
});

// =====================================================================
// FLUXO 5 — Tela de atividades redireciona sem login
// =====================================================================
test('[FLOW-05] Atividades redireciona para login se não autenticado', async ({ page }) => {
    // Garante que não há token
    await page.addInitScript(() => localStorage.removeItem('token'));
    await page.goto('/atividades.html');

    // Aguarda redirecionamento para login (o script detecta ausência de token)
    await page.waitForURL(/login\.html/, { timeout: 6000 }).catch(() => {
        // Aceita também se a página simplesmente não carrega atividades
    });
    // Pelo menos a tela deve ter o skip-link de acessibilidade ou ter redirecionado
    const currentUrl = page.url();
    const isLoginPage = currentUrl.includes('login');
    const hasSkipLink = await page.locator('.skip-link').count() > 0;
    expect(isLoginPage || hasSkipLink).toBeTruthy();
});

// =====================================================================
// FLUXO 6 — Modal de cancelamento tem foco gerenciado corretamente
// =====================================================================
test('[FLOW-06] Modal de cancelar atividade tem atributos de acessibilidade', async ({ page }) => {
    await page.goto('/atividades.html');

    const modal = page.locator('#cancelModal');
    // O modal deve existir no DOM
    await expect(modal).toBeAttached();

    // Deve ter role="dialog" e aria-modal
    await expect(modal).toHaveAttribute('role', 'dialog');
    await expect(modal).toHaveAttribute('aria-modal', 'true');

    // Deve ter aria-labelledby apontando para o título
    const labelledBy = await modal.getAttribute('aria-labelledby');
    expect(labelledBy).toBeTruthy();
    await expect(page.locator(`#${labelledBy}`)).toBeAttached();
});

// =====================================================================
// FLUXO 7 — Zoom 200%: elemento de navegação não transborda
// =====================================================================
test('[FLOW-07] Zoom 200% — nav inferior não transborda a viewport', async ({ page }) => {
    // deviceScaleFactor=2 configurado no projeto "Desktop — zoom 200%"
    await page.goto('/atividades.html');

    const navItems = page.locator('.bottom-nav .nav-item');
    const count = await navItems.count();
    const viewportWidth = page.viewportSize().width;

    for (let i = 0; i < count; i++) {
        const box = await navItems.nth(i).boundingBox();
        if (box) {
            expect(box.x + box.width).toBeLessThanOrEqual(viewportWidth + 4);
        }
    }
});

// =====================================================================
// FLUXO 8 — Cabeçalhos seguem hierarquia correta (H1 > H2 > H3)
// =====================================================================
test('[FLOW-08] Hierarquia de cabeçalhos correta', async ({ page }) => {
    for (const path of ['/cardapio.html', '/noticias.html', '/atividades.html']) {
        await page.goto(path);

        const h1Count = await page.locator('h1').count();
        expect(h1Count, `${path} deve ter exatamente 1 H1`).toBe(1);

        // H3 não deve aparecer antes de H2
        const headings = await page.locator('h1, h2, h3, h4').all();
        let lastLevel = 0;
        for (const h of headings) {
            const tag = await h.evaluate(el => el.tagName.toLowerCase());
            const level = parseInt(tag.replace('h', ''));
            // Nunca pula mais de 1 nível
            expect(level - lastLevel).toBeLessThanOrEqual(2);
            lastLevel = level;
        }
    }
});
