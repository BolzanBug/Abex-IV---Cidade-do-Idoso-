# Portal Cidade do Idoso — UNOCHAPECÓ 2026

Sistema web de gestão de atividades, cardápio e comunicados para o Centro de Atividades Roberto Carlos em Chapecó/SC.

---

## Stack

| Camada | Tecnologia |
|--------|-----------|
| Backend | Python 3.12 + FastAPI + SQLAlchemy (async) |
| Banco de dados | PostgreSQL 16 |
| Cache | Redis 7 (write-through + métricas) |
| Frontend | HTML5 + CSS3 + JavaScript (vanilla) |
| Servidor web | Nginx |
| Containers | Docker + Docker Compose |
| Testes backend | pytest + pytest-asyncio |
| Testes E2E | Playwright |
| CI/CD | GitHub Actions |
| Migrations | Alembic |

---

## Executar localmente

```bash
# Clone e suba todos os serviços
git clone <repo>
cd cidade-do-idoso

cp .env.example .env   # ajuste as variáveis se necessário

docker compose up --build
```

Acesso:
- **Frontend:** http://localhost:8080
- **API (Swagger):** http://localhost:8000/docs
- **Redoc:** http://localhost:8000/redoc

---

## Variáveis de ambiente (`.env`)

```env
DATABASE_URL=postgresql+asyncpg://postgres:postgres@db:5432/cidade_idoso
SECRET_KEY=troque-por-chave-secreta-forte
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
REDIS_URL=redis://redis:6379/0
```

---

## Funcionalidades implementadas por Sprint

### Sprint 1 — Estrutura base
- Autenticação JWT (login, cadastro, recuperação de senha)
- Cadastro de usuários idosos
- Home page com dados dinâmicos
- Backend: FastAPI + PostgreSQL + SQLAlchemy

### Sprint 2 — Backend Python (refatoração completa)
- Migração de Java/Spring Boot → Python/FastAPI
- Persistência via SQLAlchemy + PostgreSQL (mantida)
- Validações via Pydantic
- Docker Compose atualizado
- Endpoints: Login, Cadastro, Recuperação de Senha, Listagem de Idosos, Home, Notícias, Atividades

### Sprint 3 — Continuidade e qualidade do backend
- CRUD completo de Notícias (com upload/gestão de imagens)
- Sistema de inscrição em atividades com regras de negócio
- Testes automatizados com **pytest** (unitários e integração)
- Documentação automática da API via **Swagger UI**
- Versionamento de banco com **Alembic** (migrations)
- Padronização da estrutura de pastas e nomenclatura
- Segurança: autenticação JWT com controle de expiração e refresh token

### Sprint 4 — Monitoramento, Performance e Dashboard
- **Logs estruturados** via middleware FastAPI (`RequestLoggingMiddleware`)
  - Registra método, path, status HTTP, tempo de resposta e request ID por requisição
- **Cache Redis** para endpoints de cardápio e notícias (TTL: 5 min)
- **Dashboard Administrativo MVP**: indicadores do sistema (usuários, inscrições, presenças, notícias)
- Ajustes de acessibilidade nas telas principais
- Ampliação da cobertura de testes automatizados

### Sprint 5 — Acessibilidade, Usabilidade e Consolidação Final

#### Acessibilidade (WCAG AA) — todas as telas secundárias
- Refatoração de **pixels → unidades relativas** (`rem`/`em`) em CSS de atividades, cardápio e notícias
- Conformidade de contraste em todos os elementos interativos (≥ 4,5:1 para texto normal, ≥ 3:1 para texto grande)
- Renderização correta com **zoom de até 200%** em desktop e mobile
- Atributos ARIA implementados: `aria-label`, `aria-live`, `aria-current`, `aria-labelledby`, `role`, `aria-modal`
- **Skip links** (`#main-content`) em todas as telas secundárias
- Navegação por teclado funcional com foco visível (`:focus-visible`)
- `arquivo: frontend/accessibility.css` — folha de estilos WCAG AA compartilhada

#### Dashboard Administrativo evoluído
- **Gráfico de linha**: histórico de inscrições por semana (últimas 12 semanas)
- **Gráfico de barras**: uso comparativo das funcionalidades (inscrições, notícias, cardápio, presenças)
- **Gráfico de barras**: crescimento mensal de cadastros (últimos 6 meses)
- **Alertas automáticos**: notificação quando atividade ultrapassa 90% da capacidade
- **Taxa de presença por atividade** com barra de progresso e classificação (alta/média/baixa)
- **Endpoint `/dashboard/metrics/cache`**: hit rate, miss rate, erros do Redis

#### Exportação CSV
- `GET /dashboard/exportar-inscricoes` — relatório CSV com inscrições, dados do idoso e total de presenças
- Download automático via interface do Dashboard

#### Levantamento de requisitos (Gestora Luana)
- Reunião estruturada realizada — ata documentada
- **3 métricas prioritárias definidas**: taxa de presença, crescimento de cadastros, notícias acessadas
- **Novas demandas no backlog**: módulo QR Code de presença, comunicados por grupo de atividade

#### Testes de usabilidade automatizados (Playwright)
- 8 testes de acessibilidade (`tests/playwright/tests/acessibilidade.spec.js`):
  - Skip link presente e funcional
  - Navegação por teclado com aria-label
  - Atributos ARIA nos componentes (cardápio, notícias, atividades)
  - Layout sem quebra a zoom 150% e 200%
  - Todas as imagens com `alt`
  - Botões com nome acessível
- 8 testes de fluxo de usuário (`tests/playwright/tests/fluxos-usuario.spec.js`):
  - Página de login renderiza formulário
  - Cardápio e notícias carregam sem login
  - Navegação entre telas via bottom nav
  - Redirecionamento para login sem autenticação
  - Modal com atributos de acessibilidade
  - Hierarquia correta de cabeçalhos (H1 > H2 > H3)
- Simulação de zoom 150% e 200% via `deviceScaleFactor` + viewport reduzido
- **Integração ao pipeline CI/CD** (GitHub Actions) como gate de qualidade

#### Segurança — Sprint 5
- **Refresh token automático no frontend** (`api-base.js`): ao receber 401, renova o JWT e repete a requisição — elimina relogin após expiração de sessão
- `/auth/refresh_token` endpoint no backend
- **Auditoria de acesso por role**: log de tentativas de acesso a rotas administrativas (`security.py`)
- Proteção de rotas staff com `get_current_staff_user` + log de negação

#### Cache write-through — Sprint 5
- Política write-through em **cardápio**, **notícias** e **atividades**
- Ao criar/editar/deletar qualquer recurso, o cache correspondente é invalidado imediatamente
- Endpoint `/dashboard/metrics/cache` com hit rate, miss rate e disponibilidade do Redis

---

## Rotas da API

### Autenticação
| Método | Rota | Descrição |
|--------|------|-----------|
| POST | `/auth/token` | Login — retorna JWT |
| POST | `/auth/refresh_token` | Renova JWT sem relogin |

### Usuários
| Método | Rota | Descrição |
|--------|------|-----------|
| POST | `/users/` | Cadastro de novo usuário |
| GET | `/users/me` | Dados do usuário autenticado |
| PUT | `/users/me` | Atualiza perfil |

### Atividades
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/atividades/catalogo` | Lista todas as atividades |
| GET | `/atividades/minhas-inscricoes` | Inscrições do usuário |
| POST | `/atividades/inscricoes` | Inscrever-se em atividade |
| POST | `/atividades/inscricoes/{id}/cancelar` | Cancelar inscrição |
| POST | `/atividades/` | Criar atividade (staff) |
| PATCH | `/atividades/{id}` | Editar atividade (staff) |
| DELETE | `/atividades/{id}` | Remover atividade (staff) |
| GET | `/atividades/{id}/inscricoes` | Inscritos na atividade (staff) |
| GET | `/atividades/{id}/presenca` | Lista de presença (staff) |
| PUT | `/atividades/{id}/presenca` | Registrar presença (staff) |

### Cardápio
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/cardapio/` | Cardápio da semana (cache 5 min) |
| POST | `/cardapio/itens` | Adicionar item (staff) |
| PUT | `/cardapio/itens/{id}` | Editar item (staff) |
| DELETE | `/cardapio/itens/{id}` | Remover item (staff) |

### Notícias
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/noticias` | Lista notícias (cache 5 min) |
| POST | `/noticias` | Criar notícia (staff) |
| PATCH | `/noticias/{id}` | Editar notícia (staff) |
| DELETE | `/noticias/{id}` | Remover notícia (staff) |

### Dashboard (staff)
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/dashboard/resumo` | KPIs gerais |
| GET | `/dashboard/inscricoes/historico-semanal` | Gráfico de linha — 12 semanas |
| GET | `/dashboard/uso-funcionalidades` | Gráfico de barras — uso |
| GET | `/dashboard/alertas` | Alertas de capacidade (>90%) |
| GET | `/dashboard/atividades/taxa-presenca` | Taxa de presença por atividade |
| GET | `/dashboard/usuarios/crescimento-mensal` | Cadastros últimos 6 meses |
| GET | `/dashboard/exportar-inscricoes` | Download CSV de inscrições |
| GET | `/dashboard/metrics/cache` | Métricas Redis |
| DELETE | `/dashboard/cache/invalidar` | Invalida cache manualmente |

---

## Testes

### Backend (pytest)
```bash
cd backend
pytest --tb=short -q
```

### Playwright (E2E + acessibilidade)
```bash
cd tests/playwright
npm install
npx playwright install chromium
npx playwright test
```

### CI/CD
O pipeline do GitHub Actions (`.github/workflows/ci.yml`) executa automaticamente:
1. **pytest** (backend)
2. **Playwright** (gate de qualidade — zoom 150%, zoom 200%, acessibilidade, fluxos)
3. **Docker build** (verifica que as imagens constroem sem erro)

---

## Backlog (próximas iterações)
- [ ] Módulo de controle de presença por QR Code
- [ ] Sistema de comunicados direcionados por grupo de atividade
- [ ] Ampliação dos testes Playwright para fluxos administrativos do Dashboard
- [ ] Sessão de testes presencial com idosos no Parque da EFAPI
- [ ] Push notifications via PWA
- [ ] Manual do usuário em linguagem simples (com prints anotados)
