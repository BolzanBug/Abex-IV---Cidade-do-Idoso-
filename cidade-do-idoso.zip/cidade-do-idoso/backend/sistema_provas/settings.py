from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        # Tenta ler o .env mas não falha se ausente —
        # em Docker as variáveis já chegam injetadas pelo env_file: do compose.
        env_file=('.env', '/app/.env'),
        env_file_encoding='utf-8',
        extra='ignore',
    )
    DATABASE_URL: str
    SECRET_KEY: str
    ALGORITHM: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int
    ANTHROPIC_API_KEY: str = ''
    REDIS_URL: str = 'redis://redis:6379/0'
    # E-mail (SMTP) — opcional. Se não configurado, link de reset vai apenas para o log.
    SMTP_HOST: str = ''
    SMTP_PORT: int = 587
    SMTP_USER: str = ''
    SMTP_PASSWORD: str = ''
    SMTP_FROM: str = 'noreply@cidadedoidoso.chapeco.sc.gov.br'
    FRONTEND_URL: str = 'http://localhost:8080'
    PASSWORD_RESET_EXPIRE_MINUTES: int = 60
