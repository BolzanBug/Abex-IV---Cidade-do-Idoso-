"""
Configuração de logs estruturados para monitoramento — Sprint 4.
Registra requisições, erros e tempo de resposta em formato estruturado.
"""
import logging
import time
import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

# Configura handler de log com formato estruturado
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
    datefmt='%Y-%m-%dT%H:%M:%S',
)

logger = logging.getLogger('cidade_idoso.requests')


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware de log estruturado: registra cada requisição com tempo de resposta."""

    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = str(uuid.uuid4())[:8]
        start = time.perf_counter()

        # Log de entrada
        logger.info(
            'IN  | id=%s | %s %s | ip=%s',
            request_id,
            request.method,
            request.url.path,
            request.client.host if request.client else 'unknown',
        )

        try:
            response = await call_next(request)
            elapsed_ms = round((time.perf_counter() - start) * 1000, 2)
            level = logging.WARNING if response.status_code >= 400 else logging.INFO
            logger.log(
                level,
                'OUT | id=%s | %s %s | status=%d | %sms',
                request_id,
                request.method,
                request.url.path,
                response.status_code,
                elapsed_ms,
            )
            response.headers['X-Request-Id'] = request_id
            response.headers['X-Response-Time'] = f'{elapsed_ms}ms'
            return response
        except Exception as exc:
            elapsed_ms = round((time.perf_counter() - start) * 1000, 2)
            logger.error(
                'ERR | id=%s | %s %s | %sms | %s',
                request_id,
                request.method,
                request.url.path,
                elapsed_ms,
                exc,
                exc_info=True,
            )
            raise
