import asyncio
from datetime import date

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sistema_provas.database import engine
from sistema_provas.models import User
from sistema_provas.security import get_password_hash


USUARIOS = [
    {
        "username": "idoso",
        "email": "idoso@teste.com",
        "password": "123456",
        "first_name": "João",
        "last_name": "Silva",
        "phone": "49999999999",
        "birth_date": date(1950, 1, 1),
        "gender": "Masculino",
        "address": "Rua Teste",
        "city": "Chapecó",
        "state": "SC",
        "zip_code": "89800-000",
        "is_staff": False,
    },
    {
        "username": "funcionario",
        "email": "funcionario@teste.com",
        "password": "123456",
        "first_name": "Maria",
        "last_name": "Oliveira",
        "phone": "49988888888",
        "birth_date": date(1995, 1, 1),
        "gender": "Feminino",
        "address": "Rua Central",
        "city": "Chapecó",
        "state": "SC",
        "zip_code": "89800-000",
        "is_staff": True,
    },
]


async def seed():

    async with AsyncSession(engine, expire_on_commit=False) as session:

        for dados in USUARIOS:

            usuario = await session.scalar(
                select(User).where(User.email == dados["email"])
            )

            if usuario:
                print(f"Usuário {dados['email']} já existe.")
                continue

            novo = User(
                username=dados["username"],
                email=dados["email"],
                password=get_password_hash(dados["password"]),
                first_name=dados["first_name"],
                last_name=dados["last_name"],
                phone=dados["phone"],
                birth_date=dados["birth_date"],
                gender=dados["gender"],
                address=dados["address"],
                city=dados["city"],
                state=dados["state"],
                zip_code=dados["zip_code"],
                is_staff=dados["is_staff"],
            )

            session.add(novo)

            print(f"Usuário {dados['email']} criado.")

        await session.commit()


if __name__ == "__main__":
    asyncio.run(seed())