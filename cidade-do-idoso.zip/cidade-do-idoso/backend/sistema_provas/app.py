from http import HTTPStatus

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from sistema_provas.logging_config import RequestLoggingMiddleware
from sistema_provas.routers import atividades, auth, cardapio, dashboard, noticias, password, users
from sistema_provas.schemas import Message

app = FastAPI(
    title='Portal Cidade do Idoso — API',
    description='Backend do Portal Cidade do Idoso — UNOCHAPECÓ 2026',
    version='5.0.0',
)

# --- Middleware de logs estruturados (Sprint 4) ---
app.add_middleware(RequestLoggingMiddleware)

# --- CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=(
        r'https?://('
        r'localhost|127\.0\.0\.1|\[::1\]|0\.0\.0\.0'
        r'|192\.168\.\d{1,3}\.\d{1,3}'
        r'|10\.\d{1,3}\.\d{1,3}\.\d{1,3}'
        r')(:\d+)?'
    ),
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.include_router(users.router)
app.include_router(auth.router)
app.include_router(noticias.router)
app.include_router(password.router)
app.include_router(atividades.router)
app.include_router(cardapio.router)
app.include_router(dashboard.router)


@app.get('/', status_code=HTTPStatus.OK, response_model=Message)
def read_root():
    return {'Message': 'Portal Cidade do Idoso — API v5.0'}
