import logging
from http import HTTPStatus
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sistema_provas.database import get_session
from sistema_provas.models import User
from sistema_provas.schemas import Token
from sistema_provas.security import (
    create_access_token,
    get_current_user,
    verify_password,
)

OAuth2Form = Annotated[OAuth2PasswordRequestForm, Depends()]
Session = Annotated[AsyncSession, Depends(get_session)]
router = APIRouter(prefix='/auth', tags=['auth'])
CurrentUser = Annotated[User, Depends(get_current_user)]

logger = logging.getLogger('cidade_idoso.auth')


@router.post('/token', response_model=Token)
async def login_for_access_token(
    form_data: OAuth2Form,
    session: Session,
):
    """Login — retorna JWT de acesso."""
    user = await session.scalar(
        select(User).where((User.email == form_data.username))
    )

    exception = HTTPException(
        status_code=HTTPStatus.UNAUTHORIZED,
        detail='Incorrect email or password',
    )

    if not user:
        logger.warning('Tentativa de login com email inexistente: %s', form_data.username)
        raise exception

    if not verify_password(form_data.password, user.password):
        logger.warning('Senha incorreta para: %s', form_data.username)
        raise exception

    access_token = create_access_token(data={'sub': user.email})
    logger.info('Login bem-sucedido | user_id=%s | email=%s', user.id, user.email)

    return {'access_token': access_token, 'token_type': 'Bearer'}


@router.post('/refresh_token', response_model=Token)
async def refresh_access_token(user: CurrentUser):
    """
    Renova o token JWT sem exigir relogin.
    Sprint 5 — elimina interrupções de sessão para o usuário idoso.
    """
    new_access_token = create_access_token(data={'sub': user.email})
    logger.info('Token renovado | user_id=%s', user.id)
    return {'access_token': new_access_token, 'token_type': 'bearer'}
