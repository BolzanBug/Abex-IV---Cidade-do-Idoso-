import asyncio
import logging
import secrets
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from http import HTTPStatus
from typing import Annotated

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sistema_provas.database import get_session
from sistema_provas.models import PasswordResetToken, User
from sistema_provas.security import get_password_hash
from sistema_provas.settings import Settings

logger = logging.getLogger(__name__)
settings = Settings()

router = APIRouter(prefix='/password', tags=['password'])
Session = Annotated[AsyncSession, Depends(get_session)]


# ── Schemas ────────────────────────────────────────────────────────────────

class PasswordResetRequestBody(BaseModel):
    email: EmailStr


class PasswordResetConfirmBody(BaseModel):
    token: str
    new_password: str


# ── Helpers ────────────────────────────────────────────────────────────────

def _now_naive() -> datetime:
    """Retorna datetime UTC sem timezone (compatível com TIMESTAMP WITHOUT TIME ZONE do Postgres)."""
    return datetime.utcnow()


_SMTP_TIMEOUT = 10  # segundos — evita bloquear o event loop por mais que isso


def _send_reset_email_sync(to_email: str, reset_link: str) -> bool:
    """
    Envio SMTP síncrono — deve ser chamado via asyncio.to_thread(), nunca direto
    em código async, pois smtplib é bloqueante.
    """
    logger.info(
        'SMTP config → host=%r  port=%s  user=%r  from=%r',
        settings.SMTP_HOST, settings.SMTP_PORT,
        settings.SMTP_USER, settings.SMTP_FROM,
    )
    if not settings.SMTP_HOST or not settings.SMTP_USER:
        logger.warning('SMTP não configurado (SMTP_HOST ou SMTP_USER vazios). E-mail não enviado.')
        return False

    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = 'Redefinição de Senha — Portal Cidade do Idoso'
        msg['From'] = settings.SMTP_FROM
        msg['To'] = to_email

        html_body = f"""
        <html><body style="font-family:Arial,sans-serif;background:#f4f4f4;padding:20px;">
          <div style="max-width:500px;margin:0 auto;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.1);">
            <div style="background:linear-gradient(135deg,#01200F 0%,#00B931 100%);padding:32px;text-align:center;">
              <h1 style="color:white;margin:0;font-size:24px;">Cidade do Idoso</h1>
              <p style="color:rgba(255,255,255,0.85);margin:8px 0 0;">Chapecó – Santa Catarina</p>
            </div>
            <div style="padding:32px;">
              <h2 style="color:#01200F;margin-top:0;">Redefinição de Senha</h2>
              <p style="color:#555;line-height:1.6;">Recebemos uma solicitação para redefinir a senha da sua conta. Clique no botão abaixo para criar uma nova senha:</p>
              <div style="text-align:center;margin:32px 0;">
                <a href="{reset_link}" style="background:#00B931;color:white;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold;font-size:16px;display:inline-block;">
                  Redefinir Minha Senha
                </a>
              </div>
              <p style="color:#888;font-size:13px;">Este link é válido por {settings.PASSWORD_RESET_EXPIRE_MINUTES} minutos. Se você não solicitou a redefinição, ignore este e-mail — sua senha permanece a mesma.</p>
              <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
              <p style="color:#aaa;font-size:12px;text-align:center;">Portal Cidade do Idoso · Chapecó, SC</p>
            </div>
          </div>
        </body></html>
        """

        msg.attach(MIMEText(html_body, 'html'))

        # timeout=_SMTP_TIMEOUT garante que a thread não fica pendurada para sempre
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=_SMTP_TIMEOUT) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            smtp.sendmail(settings.SMTP_FROM, to_email, msg.as_string())

        logger.info('E-mail de reset enviado para %s', to_email)
        return True

    except Exception as exc:
        logger.error('Falha ao enviar e-mail para %s: %s', to_email, exc)
        return False


async def _send_reset_email(to_email: str, reset_link: str) -> bool:
    """
    Wrapper async: executa o envio SMTP em uma thread do ThreadPoolExecutor
    para não bloquear o event loop do FastAPI/uvicorn.
    """
    return await asyncio.to_thread(_send_reset_email_sync, to_email, reset_link)


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post('/reset-request')
async def solicitar_redefinicao_senha(
    body: PasswordResetRequestBody,
    session: Session,
):
    """
    Solicita redefinição de senha.
    - Sempre retorna 200 (evita enumeração de e-mails).
    - Cria token válido por PASSWORD_RESET_EXPIRE_MINUTES minutos.
    - Se SMTP configurado: envia e-mail. Caso contrário: loga o link.
    """
    user = await session.scalar(select(User).where(User.email == body.email))

    if not user:
        logger.info('Reset solicitado para e-mail não cadastrado: %s', body.email)
        return JSONResponse(status_code=HTTPStatus.OK, content={'sent': False})

    # Invalida tokens anteriores do usuário
    existing_tokens = await session.scalars(
        select(PasswordResetToken).where(
            PasswordResetToken.user_id == user.id,
            PasswordResetToken.used == False,  # noqa: E712
        )
    )
    for old_token in existing_tokens:
        old_token.used = True
        session.add(old_token)

    # Cria novo token — usa datetime naive (sem tz) para TIMESTAMP WITHOUT TIME ZONE
    raw_token = secrets.token_urlsafe(48)
    expires_at = _now_naive() + timedelta(minutes=settings.PASSWORD_RESET_EXPIRE_MINUTES)

    reset_token = PasswordResetToken(
        user_id=user.id,
        token=raw_token,
        expires_at=expires_at,
    )
    session.add(reset_token)
    await session.commit()

    reset_link = f'{settings.FRONTEND_URL}/redefinir-senha.html?token={raw_token}'

    email_sent = await _send_reset_email(user.email, reset_link)

    if not email_sent:
        logger.info(
            '[DEV] Link de redefinição de senha para %s → %s',
            user.email,
            reset_link,
        )

    return JSONResponse(
        status_code=HTTPStatus.OK,
        content={'sent': email_sent},
    )


@router.post('/reset-confirm')
async def confirmar_redefinicao_senha(
    body: PasswordResetConfirmBody,
    session: Session,
):
    """Confirma a redefinição de senha com token + nova senha."""
    now = _now_naive()

    token_obj = await session.scalar(
        select(PasswordResetToken).where(
            PasswordResetToken.token == body.token,
            PasswordResetToken.used == False,  # noqa: E712
        )
    )

    if not token_obj:
        return JSONResponse(
            status_code=HTTPStatus.BAD_REQUEST,
            content={'message': 'Token inválido ou já utilizado.'},
        )

    # expires_at vem do banco como naive — comparação direta
    if now > token_obj.expires_at:
        token_obj.used = True
        session.add(token_obj)
        await session.commit()
        return JSONResponse(
            status_code=HTTPStatus.BAD_REQUEST,
            content={'message': 'Token expirado. Solicite um novo link.'},
        )

    if len(body.new_password) < 6:
        return JSONResponse(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            content={'message': 'A nova senha deve ter ao menos 6 caracteres.'},
        )

    user = await session.get(User, token_obj.user_id)
    if not user:
        return JSONResponse(
            status_code=HTTPStatus.NOT_FOUND,
            content={'message': 'Usuário não encontrado.'},
        )

    user.password = get_password_hash(body.new_password)
    token_obj.used = True
    session.add(user)
    session.add(token_obj)
    await session.commit()

    logger.info('Senha redefinida com sucesso para user_id=%s', user.id)
    return JSONResponse(status_code=HTTPStatus.OK, content={'ok': True})


@router.get('/reset-validate')
async def validar_token(token: str, session: Session):
    """Verifica se um token de reset ainda é válido (usado pelo frontend)."""
    now = _now_naive()

    token_obj = await session.scalar(
        select(PasswordResetToken).where(
            PasswordResetToken.token == token,
            PasswordResetToken.used == False,  # noqa: E712
        )
    )

    if not token_obj:
        return JSONResponse(
            status_code=HTTPStatus.OK,
            content={'valid': False, 'reason': 'Token inválido ou já utilizado.'},
        )

    if now > token_obj.expires_at:
        return JSONResponse(
            status_code=HTTPStatus.OK,
            content={'valid': False, 'reason': 'Token expirado.'},
        )

    return JSONResponse(status_code=HTTPStatus.OK, content={'valid': True})
