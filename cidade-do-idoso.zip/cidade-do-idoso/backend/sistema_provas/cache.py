"""
Módulo de cache Redis com política write-through e métricas de hit/miss.
Sprint 4 e 5 — Portal Cidade do Idoso.
"""
import json
import logging
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Métricas globais de cache
_metrics: dict[str, int] = {
    'hits': 0,
    'misses': 0,
    'total_requests': 0,
    'errors': 0,
}

# Tentativas de conexão com Redis
_redis_client: Any = None
_redis_available = False


async def get_redis():
    """Retorna cliente Redis ou None se indisponível."""
    global _redis_client, _redis_available
    if _redis_client is not None:
        return _redis_client if _redis_available else None
    try:
        import redis.asyncio as aioredis
        from sistema_provas.settings import Settings
        s = Settings()
        redis_url = getattr(s, 'REDIS_URL', 'redis://redis:6379/0')
        _redis_client = aioredis.from_url(
            redis_url, encoding='utf-8', decode_responses=True,
            socket_connect_timeout=2,
        )
        await _redis_client.ping()
        _redis_available = True
        logger.info('Redis conectado: %s', redis_url)
    except Exception as exc:
        logger.warning('Redis indisponível (cache desativado): %s', exc)
        _redis_available = False
        _redis_client = None
    return _redis_client if _redis_available else None


async def cache_get(key: str) -> Optional[Any]:
    """Busca valor no cache. Atualiza métricas de hit/miss."""
    _metrics['total_requests'] += 1
    client = await get_redis()
    if client is None:
        _metrics['misses'] += 1
        return None
    try:
        raw = await client.get(key)
        if raw is None:
            _metrics['misses'] += 1
            return None
        _metrics['hits'] += 1
        return json.loads(raw)
    except Exception as exc:
        logger.warning('Erro ao ler cache [%s]: %s', key, exc)
        _metrics['errors'] += 1
        _metrics['misses'] += 1
        return None


async def cache_set(key: str, value: Any, ttl: int = 300) -> bool:
    """Armazena valor no cache com TTL em segundos."""
    client = await get_redis()
    if client is None:
        return False
    try:
        await client.setex(key, ttl, json.dumps(value, default=str))
        return True
    except Exception as exc:
        logger.warning('Erro ao gravar cache [%s]: %s', key, exc)
        _metrics['errors'] += 1
        return False


async def cache_delete(key: str) -> bool:
    """Remove chave do cache (invalidação write-through)."""
    client = await get_redis()
    if client is None:
        return False
    try:
        await client.delete(key)
        return True
    except Exception as exc:
        logger.warning('Erro ao deletar cache [%s]: %s', key, exc)
        return False


async def cache_delete_pattern(pattern: str) -> int:
    """Remove todas as chaves que correspondem ao padrão (write-through)."""
    client = await get_redis()
    if client is None:
        return 0
    try:
        keys = await client.keys(pattern)
        if keys:
            return await client.delete(*keys)
        return 0
    except Exception as exc:
        logger.warning('Erro ao deletar padrão [%s]: %s', pattern, exc)
        return 0


def get_cache_metrics() -> dict:
    """Retorna métricas de hit rate para o endpoint /metrics/cache."""
    total = _metrics['total_requests']
    hits = _metrics['hits']
    misses = _metrics['misses']
    hit_rate = round(hits / total * 100, 2) if total > 0 else 0.0
    miss_rate = round(misses / total * 100, 2) if total > 0 else 0.0
    return {
        'hits': hits,
        'misses': misses,
        'total_requests': total,
        'errors': _metrics['errors'],
        'hit_rate_percent': hit_rate,
        'miss_rate_percent': miss_rate,
        'redis_available': _redis_available,
    }
