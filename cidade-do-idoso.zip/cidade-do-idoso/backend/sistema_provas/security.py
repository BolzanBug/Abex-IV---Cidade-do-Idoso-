import logging
from datetime import datetime, timedelta
from http import HTTPStatus
from zoneinfo import ZoneInfo

from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jwt import DecodeError, ExpiredSignatureError, decode, encode
from pwdlib import PasswordHash
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sistema_provas.database import get_session
from sistema_provas.models import User
from sistema_provas.settings import Settings

oauth2_scheme = OAuth2PasswordBearer(tokenUrl='auth/token')
pwd_context = PasswordHash.recommended()
settings = Settings()

logger = logging.getLogger('cidade_idoso.security')


def get_password_hash(password: str):
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str):
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(tz=ZoneInfo('UTC')) + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    to_encode.update({'exp': expire})
    encoded_jwt = encode(
        to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM
    )
    return encoded_jwt


async def get_current_user(
    session: AsyncSession = Depends(get_session),
    token: str = Depends(oauth2_scheme),
):
    credentials_exception = HTTPException(
        status_code=HTTPStatus.UNAUTHORIZED,
        detail='Could not validate credentials',
        headers={'WWW-Authenticate': 'Bearer'},
    )

    try:
        payload = decode(
            token, settings.SECRET_KEY, algorithms=settings.ALGORITHM
        )
        subject_email = payload.get('sub')
        if not subject_email:
            raise credentials_exception
    except DecodeError:
        logger.warning('Token inválido: DecodError')
        raise credentials_exception
    except ExpiredSignatureError:
        logger.info('Token expirado para: %s', 'desconhecido')
        raise credentials_exception

    user = await session.scalar(
        select(User).where(User.email == subject_email)
    )

    if not user:
        logger.warning('Usuário não encontrado para email: %s', subject_email)
        raise credentials_exception

    return user


async def get_current_staff_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """
    Garante acesso apenas a usuários staff — auditoria de acesso por role.
    Sprint 5: proteção avançada de rotas administrativas.
    """
    if not current_user.is_staff:
        logger.warning(
            'Acesso negado a rota administrativa | user_id=%s | email=%s',
            current_user.id,
            current_user.email,
        )
        raise HTTPException(
            status_code=HTTPStatus.FORBIDDEN,
            detail='Acesso restrito a funcionários',
        )
    logger.info(
        'Acesso staff autorizado | user_id=%s | email=%s',
        current_user.id,
        current_user.email,
    )
    return current_user
