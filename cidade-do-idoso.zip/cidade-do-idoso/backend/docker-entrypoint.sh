#!/bin/sh
set -e

echo "Aguardando PostgreSQL em ${DB_HOST:-db}..."
until pg_isready -h "${DB_HOST:-db}" -U "${POSTGRES_USER:-postgres}" -q; do
  sleep 1
done

echo "Executando migrations..."
poetry run alembic upgrade head

echo "Criando usuários de teste..."
poetry run python -m sistema_provas.seed

echo "Iniciando API..."
exec poetry run uvicorn sistema_provas.app:app --host 0.0.0.0 --port 8000